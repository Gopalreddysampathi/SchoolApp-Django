from django.shortcuts import render,redirect
from django.http import HttpResponse
from admissions.models import Student
from admissions.forms import StudentModelForm
from admissions.forms import VendorForm
from django.views.generic import View,ListView,DetailView,CreateView
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
# Create your views here.
def home(request):
    return render(request, 'home.html')

def addadmissions(request):
        form = StudentModelForm
        studentform = {'form':form}
        if request.method=='POST':
            form = StudentModelForm(request.POST)
            if form.is_valid():
                form.save()
                return admissionsreports(request)
        return render(request, 'admissions/admissionreport.html',studentform )
def admissionsreports(request):
        form=Student.objects.all()
        studentdetails={'form':form}
 
        return render(request, 'admissions/admissionreport.html',studentdetails)
def deleteStudent(request,id):
    s=Student.objects.get(id=id)
    s.delete()
    return admissionsreports(request)

def updateStudent(request,id):
    s=Student.objects.get(id=id)
    form = StudentModelForm(instance=s)
    dict = {'form':form}
    if request.method=='POST':
        form = StudentModelForm(request.POST,instance=s)
        if form.is_valid():
            form.save()
        return admissionsreports(request)

    return render(request,'admissions/update-student.html',dict)
def signup(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        confirm = request.POST['confirm']

        if password != confirm:
            messages.error(request, "Passwords do not match")
            return redirect('admissions:signup')

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists")
            #return redirect('admissions:signup')
            return signup(request)

        user = User.objects.create_user(
            username=username,
            email=email,
            password=password
        )
        messages.success(request, "Account created successfully")
        #return redirect('admissions:login')
        return login(request)

    return render(request, 'admissions/signup.html')


def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('dashboard')  # change if needed
        else:
            messages.error(request, "Invalid username or password")

    return render(request, 'admissions/login.html')


def logout(request):
    logout(request)
    return login(request)
