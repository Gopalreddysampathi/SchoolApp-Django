from django.contrib import admin
from django.urls import path
from admissions.views import  *

urlpatterns = [
   
    path('',home,name='home'),
     path('addadmissions/',addadmissions,name='addadmissions'),
      path('admissionsreports/',admissionsreports,name='admissionsreports'),
          path('delete/<int:id>',deleteStudent,name='deleteStudent'),
    path('update/<int:id>',updateStudent,name='updateStudent'),
       path('login/', login, name='login'),
    path('signup/', signup, name='signup'),
    path('logout/', logout, name='logout'),
      
      
]
