 
from django.urls import path
from finance.views import *
urlpatterns = [

       path('feecollection/',feecollection,name='feecollection'),
      path('feeduereport/',feeduereport,name='feeduereport'),
       path('feecollectionreport/',feecollectionreport,name='feecollectionreport'),
      
      
]
