from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def feecollection(request):
     return render(request, 'Finance/feecollection.html')
def feeduereport(request):
     return render(request, 'Finance/feeduereport.html')
def feecollectionreport(request):
     return render(request, 'Finance/feecollectionreport.html')
